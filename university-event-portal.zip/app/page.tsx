import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { EventCard } from "@/components/event-card"
import { EventSearch } from "@/components/event-search"
import { HeroSection } from "@/components/hero-section"
import { fetchEvents } from "@/lib/supabase"

export const revalidate = 3600 // Revalidate this page every hour

export default async function HomePage() {
  // Fetch different event categories
  const upcomingEvents = await fetchEvents({ upcoming: true, orderBy: "date", limit: 6 })
  const recentEvents = await fetchEvents({ orderBy: "created_at.desc", limit: 6 })
  const featuredEvent = upcomingEvents[0] || null

  return (
    <div className="flex min-h-screen flex-col">
      <HeroSection featuredEvent={featuredEvent} />

      <section className="container mx-auto px-4 py-12">
        <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-center">
          <div>
            <h2 className="text-3xl font-bold tracking-tight">Discover Events</h2>
            <p className="text-muted-foreground">Find and join exciting events happening around campus</p>
          </div>
          <EventSearch />
        </div>

        <Tabs defaultValue="upcoming" className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="upcoming">Upcoming Events</TabsTrigger>
            <TabsTrigger value="recent">Recently Added</TabsTrigger>
            <TabsTrigger value="workshops">Workshops</TabsTrigger>
            <TabsTrigger value="seminars">Seminars</TabsTrigger>
            <TabsTrigger value="hackathon">Hackathons</TabsTrigger>
          </TabsList>

          <TabsContent value="upcoming" className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {upcomingEvents.length > 0 ? (
              upcomingEvents.map((event) => <EventCard key={event.id} event={event} />)
            ) : (
              <div className="col-span-full text-center">
                <p className="text-muted-foreground">No upcoming events found.</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="recent" className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {recentEvents.length > 0 ? (
              recentEvents.map((event) => <EventCard key={event.id} event={event} />)
            ) : (
              <div className="col-span-full text-center">
                <p className="text-muted-foreground">No recent events found.</p>
              </div>
            )}
          </TabsContent>

          {["workshops", "seminars", "hackathon"].map((category) => (
            <TabsContent key={category} value={category} className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
              <EventCategoryContent category={category} />
            </TabsContent>
          ))}
        </Tabs>

        <div className="mt-8 flex justify-center">
          <Button asChild>
            <Link href="/events">
              View All Events
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>
    </div>
  )
}

async function EventCategoryContent({ category }: { category: string }) {
  const events = await fetchEvents({ category, upcoming: true, limit: 6 })

  if (events.length === 0) {
    return (
      <div className="col-span-full text-center">
        <p className="text-muted-foreground">No {category} events found.</p>
      </div>
    )
  }

  return events.map((event) => <EventCard key={event.id} event={event} />)
}
