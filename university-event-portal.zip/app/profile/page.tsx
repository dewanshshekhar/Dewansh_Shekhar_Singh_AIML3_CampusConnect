"use client"

import { useState } from "react"
import Link from "next/link"
import { ArrowLeft, Calendar, Mail, MapPin, Pencil, Phone, User } from "lucide-react"
import { motion } from "framer-motion"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { toast } from "@/components/ui/use-toast"

export default function ProfilePage() {
  // Mock user data - in a real app, this would come from authentication
  const [userRole] = useState<"student" | "faculty" | "guest">("student")

  const userData = {
    student: {
      name: "Alex Johnson",
      email: "alex.johnson@university.edu",
      role: "Student",
      department: "Computer Science",
      year: "3rd Year",
      rollNumber: "CS2023045",
      phone: "+91 9876543210",
      address: "Room 302, Student Hostel B, University Campus",
      avatar: "/placeholder.svg?height=200&width=200",
      bio: "Computer Science student with a passion for web development and AI. Active member of the university tech club and organizing committee for tech events.",
      interests: ["Web Development", "Artificial Intelligence", "Competitive Programming", "Hackathons"],
      achievements: [
        { title: "1st Place", event: "University Hackathon 2024", date: "February 2024" },
        { title: "Best Project Award", event: "CS Department Showcase", date: "November 2023" },
      ],
      upcomingEvents: [
        { id: 1, title: "Tech Innovation Summit", date: "2025-04-15T10:00:00" },
        { id: 3, title: "Web Development Workshop", date: "2025-04-25T14:00:00" },
      ],
      pastEvents: [
        { id: 4, title: "Cultural Festival", date: "2025-03-05T18:00:00" },
        { id: 9, title: "Debate Competition", date: "2025-03-01T14:00:00" },
      ],
    },
    faculty: {
      name: "Dr. Sarah Williams",
      email: "sarah.williams@university.edu",
      role: "Faculty",
      department: "Computer Science",
      position: "Associate Professor",
      phone: "+91 9876543211",
      address: "Faculty Housing Block C, University Campus",
      avatar: "/placeholder.svg?height=200&width=200",
      bio: "Associate Professor with 10+ years of experience in Computer Science education and research. Specializing in AI and Machine Learning with multiple published papers in international journals.",
      specializations: ["Artificial Intelligence", "Machine Learning", "Data Science", "Computer Vision"],
      publications: [
        {
          title: "Advances in Neural Networks for Educational Applications",
          journal: "International Journal of AI in Education",
          year: "2023",
        },
        {
          title: "Machine Learning Approaches to Student Performance Prediction",
          journal: "Educational Data Mining",
          year: "2022",
        },
      ],
      organizedEvents: [
        { id: 1, title: "Tech Innovation Summit", date: "2025-04-15T10:00:00" },
        { id: 7, title: "Entrepreneurship Summit", date: "2025-05-20T09:00:00" },
      ],
    },
    guest: {
      name: "Guest User",
      email: "guest@example.com",
      role: "Guest",
      phone: "+91 9876543212",
      avatar: "/placeholder.svg?height=200&width=200",
      bio: "Interested in university events and activities. Looking to connect with the academic community.",
      interests: ["Technology", "Education", "Networking"],
      registeredEvents: [{ id: 1, title: "Tech Innovation Summit", date: "2025-04-15T10:00:00" }],
    },
  }

  const user = userData[userRole]

  const handleEditProfile = () => {
    toast({
      title: "Edit Profile",
      description: "Profile editing functionality would be implemented here.",
    })
  }

  return (
    <div className="container mx-auto p-4 py-6">
      <div className="mb-6">
        <Button asChild variant="ghost" size="sm" className="mb-4">
          <Link href="/">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Link>
        </Button>

        <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">My Profile</h1>
            <p className="text-muted-foreground">View and manage your personal information</p>
          </div>

          <Button onClick={handleEditProfile}>
            <Pencil className="mr-2 h-4 w-4" />
            Edit Profile
          </Button>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-1">
          <CardHeader className="text-center">
            <Avatar className="mx-auto h-24 w-24">
              <AvatarImage src={user.avatar} alt={user.name} />
              <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <CardTitle className="mt-4">{user.name}</CardTitle>
            <CardDescription className="flex items-center justify-center gap-2">
              <Mail className="h-4 w-4" />
              {user.email}
            </CardDescription>
            <div className="mt-2 flex justify-center">
              <Badge>{user.role}</Badge>
            </div>
          </CardHeader>

          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h3 className="text-sm font-medium text-muted-foreground">Contact Information</h3>
              <div className="flex items-center gap-2 text-sm">
                <Phone className="h-4 w-4 text-muted-foreground" />
                <span>{user.phone}</span>
              </div>
              {user.address && (
                <div className="flex items-start gap-2 text-sm">
                  <MapPin className="mt-0.5 h-4 w-4 text-muted-foreground" />
                  <span>{user.address}</span>
                </div>
              )}
            </div>

            {userRole === "student" && (
              <div className="space-y-2">
                <h3 className="text-sm font-medium text-muted-foreground">Academic Information</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>Department:</div>
                  <div className="font-medium">{userData.student.department}</div>
                  <div>Year:</div>
                  <div className="font-medium">{userData.student.year}</div>
                  <div>Roll Number:</div>
                  <div className="font-medium">{userData.student.rollNumber}</div>
                </div>
              </div>
            )}

            {userRole === "faculty" && (
              <div className="space-y-2">
                <h3 className="text-sm font-medium text-muted-foreground">Academic Information</h3>
                <div className="grid grid-cols-2 gap-2 text-sm">
                  <div>Department:</div>
                  <div className="font-medium">{userData.faculty.department}</div>
                  <div>Position:</div>
                  <div className="font-medium">{userData.faculty.position}</div>
                </div>
              </div>
            )}

            <div className="space-y-2">
              <h3 className="text-sm font-medium text-muted-foreground">Bio</h3>
              <p className="text-sm">{user.bio}</p>
            </div>

            {(userRole === "student" || userRole === "guest") && user.interests && (
              <div className="space-y-2">
                <h3 className="text-sm font-medium text-muted-foreground">Interests</h3>
                <div className="flex flex-wrap gap-2">
                  {user.interests.map((interest) => (
                    <Badge key={interest} variant="outline">
                      {interest}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {userRole === "faculty" && userData.faculty.specializations && (
              <div className="space-y-2">
                <h3 className="text-sm font-medium text-muted-foreground">Specializations</h3>
                <div className="flex flex-wrap gap-2">
                  {userData.faculty.specializations.map((specialization) => (
                    <Badge key={specialization} variant="outline">
                      {specialization}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </CardContent>

          <CardFooter>
            <Button variant="outline" className="w-full">
              <User className="mr-2 h-4 w-4" />
              View Public Profile
            </Button>
          </CardFooter>
        </Card>

        <div className="md:col-span-2">
          <Tabs defaultValue="events">
            <TabsList className="mb-4">
              <TabsTrigger value="events">Events</TabsTrigger>
              {userRole === "student" && <TabsTrigger value="achievements">Achievements</TabsTrigger>}
              {userRole === "faculty" && <TabsTrigger value="publications">Publications</TabsTrigger>}
              <TabsTrigger value="settings">Account Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="events">
              <Card>
                <CardHeader>
                  <CardTitle>My Events</CardTitle>
                  <CardDescription>
                    {userRole === "student" && "Events you're registered for or have attended"}
                    {userRole === "faculty" && "Events you've organized or are planning"}
                    {userRole === "guest" && "Events you're registered for"}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  {userRole === "student" && (
                    <>
                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">Upcoming Events</h3>
                        {userData.student.upcomingEvents.map((event) => (
                          <motion.div
                            key={event.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.2 }}
                            className="flex items-center justify-between rounded-lg border p-4"
                          >
                            <div>
                              <h4 className="font-medium">{event.title}</h4>
                              <p className="text-sm text-muted-foreground">
                                <Calendar className="mr-1 inline-block h-3.5 w-3.5" />
                                {new Date(event.date).toLocaleDateString("en-US", {
                                  weekday: "long",
                                  year: "numeric",
                                  month: "long",
                                  day: "numeric",
                                })}
                              </p>
                            </div>
                            <Button asChild size="sm">
                              <Link href={`/events/${event.id}`}>View</Link>
                            </Button>
                          </motion.div>
                        ))}
                      </div>

                      <Separator />

                      <div className="space-y-4">
                        <h3 className="text-lg font-medium">Past Events</h3>
                        {userData.student.pastEvents.map((event) => (
                          <motion.div
                            key={event.id}
                            initial={{ opacity: 0, y: 10 }}
                            animate={{ opacity: 1, y: 0 }}
                            transition={{ duration: 0.2 }}
                            className="flex items-center justify-between rounded-lg border p-4"
                          >
                            <div>
                              <h4 className="font-medium">{event.title}</h4>
                              <p className="text-sm text-muted-foreground">
                                <Calendar className="mr-1 inline-block h-3.5 w-3.5" />
                                {new Date(event.date).toLocaleDateString("en-US", {
                                  weekday: "long",
                                  year: "numeric",
                                  month: "long",
                                  day: "numeric",
                                })}
                              </p>
                            </div>
                            <Button asChild size="sm" variant="outline">
                              <Link href={`/events/${event.id}`}>View</Link>
                            </Button>
                          </motion.div>
                        ))}
                      </div>
                    </>
                  )}

                  {userRole === "faculty" && (
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Organized Events</h3>
                      {userData.faculty.organizedEvents.map((event) => (
                        <motion.div
                          key={event.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.2 }}
                          className="flex items-center justify-between rounded-lg border p-4"
                        >
                          <div>
                            <h4 className="font-medium">{event.title}</h4>
                            <p className="text-sm text-muted-foreground">
                              <Calendar className="mr-1 inline-block h-3.5 w-3.5" />
                              {new Date(event.date).toLocaleDateString("en-US", {
                                weekday: "long",
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Button asChild size="sm" variant="outline">
                              <Link href={`/events/${event.id}/edit`}>Edit</Link>
                            </Button>
                            <Button asChild size="sm">
                              <Link href={`/events/${event.id}`}>View</Link>
                            </Button>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}

                  {userRole === "guest" && (
                    <div className="space-y-4">
                      <h3 className="text-lg font-medium">Registered Events</h3>
                      {userData.guest.registeredEvents.map((event) => (
                        <motion.div
                          key={event.id}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.2 }}
                          className="flex items-center justify-between rounded-lg border p-4"
                        >
                          <div>
                            <h4 className="font-medium">{event.title}</h4>
                            <p className="text-sm text-muted-foreground">
                              <Calendar className="mr-1 inline-block h-3.5 w-3.5" />
                              {new Date(event.date).toLocaleDateString("en-US", {
                                weekday: "long",
                                year: "numeric",
                                month: "long",
                                day: "numeric",
                              })}
                            </p>
                          </div>
                          <Button asChild size="sm">
                            <Link href={`/events/${event.id}`}>View</Link>
                          </Button>
                        </motion.div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            {userRole === "student" && (
              <TabsContent value="achievements">
                <Card>
                  <CardHeader>
                    <CardTitle>Achievements</CardTitle>
                    <CardDescription>Your awards and recognitions</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {userData.student.achievements.map((achievement, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.2, delay: index * 0.1 }}
                          className="rounded-lg border p-4"
                        >
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium">{achievement.title}</h4>
                            <Badge variant="outline">{achievement.date}</Badge>
                          </div>
                          <p className="mt-1 text-sm text-muted-foreground">{achievement.event}</p>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            )}

            {userRole === "faculty" && (
              <TabsContent value="publications">
                <Card>
                  <CardHeader>
                    <CardTitle>Publications</CardTitle>
                    <CardDescription>Your research papers and publications</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      {userData.faculty.publications.map((publication, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.2, delay: index * 0.1 }}
                          className="rounded-lg border p-4"
                        >
                          <div className="flex items-center justify-between">
                            <h4 className="font-medium">{publication.title}</h4>
                            <Badge variant="outline">{publication.year}</Badge>
                          </div>
                          <p className="mt-1 text-sm text-muted-foreground">{publication.journal}</p>
                        </motion.div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>
            )}

            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                  <CardDescription>Manage your account preferences</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="rounded-lg border p-4">
                      <h4 className="font-medium">Email Notifications</h4>
                      <p className="text-sm text-muted-foreground">Manage your email notification preferences</p>
                      <Button variant="outline" size="sm" className="mt-2">
                        Manage Notifications
                      </Button>
                    </div>

                    <div className="rounded-lg border p-4">
                      <h4 className="font-medium">Password</h4>
                      <p className="text-sm text-muted-foreground">Change your account password</p>
                      <Button variant="outline" size="sm" className="mt-2">
                        Change Password
                      </Button>
                    </div>

                    <div className="rounded-lg border p-4">
                      <h4 className="font-medium">Privacy Settings</h4>
                      <p className="text-sm text-muted-foreground">Control who can see your profile information</p>
                      <Button variant="outline" size="sm" className="mt-2">
                        Manage Privacy
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  )
}
