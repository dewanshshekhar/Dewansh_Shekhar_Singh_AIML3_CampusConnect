"use client"

import type React from "react"
import Link from "next/link"
import { Bell, Calendar, Home, LogIn, Menu, Plus, Search, User } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ThemeProvider } from "@/components/theme-provider"
import { Toaster } from "@/components/ui/toaster"
import { Sidebar } from "@/components/sidebar"
import { AuthProvider } from "@/contexts/auth-context"
import { useAuth } from "@/contexts/auth-context"

import "./globals.css"

import { Inter } from "next/font/google"
const inter = Inter({ subsets: ["latin"] })

export default function ClientLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={cn(inter.className, "min-h-screen bg-background antialiased")}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
          <AuthProvider>
            <div className="relative flex min-h-screen flex-col">
              <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
                <div className="container flex h-16 items-center justify-between">
                  <div className="flex items-center gap-2 md:gap-4">
                    <Sidebar
                      trigger={
                        <Button variant="outline" size="icon" className="md:hidden">
                          <Menu className="h-5 w-5" />
                          <span className="sr-only">Toggle menu</span>
                        </Button>
                      }
                    />
                    <Link href="/" className="flex items-center gap-2">
                      <Calendar className="h-6 w-6 text-primary" />
                      <span className="hidden text-xl font-bold sm:inline-block">CampusConnect</span>
                    </Link>
                    <nav className="hidden md:flex md:gap-2">
                      <Button asChild variant="ghost" size="sm">
                        <Link href="/">
                          <Home className="mr-2 h-4 w-4" />
                          Home
                        </Link>
                      </Button>
                      <Button asChild variant="ghost" size="sm">
                        <Link href="/events">
                          <Calendar className="mr-2 h-4 w-4" />
                          Events
                        </Link>
                      </Button>
                      <Button asChild variant="ghost" size="sm">
                        <Link href="/dashboard">
                          <User className="mr-2 h-4 w-4" />
                          Dashboard
                        </Link>
                      </Button>
                      <Button asChild variant="ghost" size="sm">
                        <Link href="/events/create">
                          <Plus className="mr-2 h-4 w-4" />
                          Create Event
                        </Link>
                      </Button>
                    </nav>
                  </div>
                  <div className="flex items-center gap-2">
                    <Button variant="ghost" size="icon" className="relative">
                      <Bell className="h-5 w-5" />
                      <span className="sr-only">Notifications</span>
                      <span className="absolute right-1.5 top-1.5 flex h-2 w-2 rounded-full bg-primary"></span>
                    </Button>
                    <Button variant="ghost" size="icon" className="md:hidden">
                      <Search className="h-5 w-5" />
                      <span className="sr-only">Search</span>
                    </Button>
                    <Sidebar
                      trigger={
                        <Button variant="ghost" size="icon" className="hidden md:flex">
                          <User className="h-5 w-5" />
                          <span className="sr-only">Profile</span>
                        </Button>
                      }
                    />
                    <AuthButtons />
                  </div>
                </div>
              </header>
              <main className="flex-1">{children}</main>
              <footer className="border-t py-6">
                <div className="container flex flex-col items-center justify-between gap-4 md:flex-row">
                  <p className="text-center text-sm text-muted-foreground md:text-left">
                    &copy; {new Date().getFullYear()} CampusConnect. All rights reserved.
                  </p>
                  <nav className="flex gap-4 text-sm text-muted-foreground">
                    <Link href="#" className="hover:underline">
                      Terms
                    </Link>
                    <Link href="#" className="hover:underline">
                      Privacy
                    </Link>
                    <Link href="#" className="hover:underline">
                      Contact
                    </Link>
                  </nav>
                </div>
              </footer>
            </div>
            <Toaster />
          </AuthProvider>
        </ThemeProvider>
      </body>
    </html>
  )
}

function AuthButtons() {
  const { user, loading } = useAuth()

  if (loading) return null

  if (user) return null // Don't show buttons when logged in

  return (
    <>
      <Button asChild size="sm" variant="outline" className="hidden md:flex">
        <Link href="/auth/register">Sign Up</Link>
      </Button>
      <Button asChild size="sm" className="hidden md:flex">
        <Link href="/auth/login">
          <LogIn className="mr-2 h-4 w-4" />
          Sign In
        </Link>
      </Button>
    </>
  )
}
