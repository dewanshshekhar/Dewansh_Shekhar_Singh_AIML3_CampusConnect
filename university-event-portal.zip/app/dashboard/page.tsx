"use client"

import type React from "react"

import { useState } from "react"
import { motion } from "framer-motion"
import { Calendar, Clock, Download, Upload, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { DashboardChart } from "@/components/dashboard-chart"
import { DashboardEventList } from "@/components/dashboard-event-list"
import { UserProfile } from "@/components/user-profile"

export default function DashboardPage() {
  const [role, setRole] = useState<"student" | "organizer" | "admin">("student")

  return (
    <div className="container mx-auto p-4 py-6">
      <div className="mb-8 flex flex-col justify-between gap-4 md:flex-row md:items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground">Manage your events and profile</p>
        </div>

        {/* Role switcher (for demo purposes) */}
        <div className="flex items-center gap-2">
          <span className="text-sm font-medium">View as:</span>
          <select
            value={role}
            onChange={(e) => setRole(e.target.value as "student" | "organizer" | "admin")}
            className="rounded-md border border-input bg-background px-3 py-1 text-sm"
          >
            <option value="student">Student</option>
            <option value="organizer">Organizer</option>
            <option value="admin">Admin</option>
          </select>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <UserProfile role={role} />

        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Quick Stats</CardTitle>
            <CardDescription>Your event participation overview</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4 sm:grid-cols-3">
              <StatsCard
                title="Registered"
                value={role === "student" ? "12" : role === "organizer" ? "5" : "32"}
                icon={<Calendar className="h-4 w-4 text-blue-500" />}
                description="Events registered"
                color="blue"
              />
              <StatsCard
                title="Attended"
                value={role === "student" ? "8" : role === "organizer" ? "3" : "24"}
                icon={<Users className="h-4 w-4 text-green-500" />}
                description="Events attended"
                color="green"
              />
              <StatsCard
                title="Upcoming"
                value={role === "student" ? "4" : role === "organizer" ? "2" : "8"}
                icon={<Clock className="h-4 w-4 text-purple-500" />}
                description="Events upcoming"
                color="purple"
              />
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="mt-6">
        <Tabs defaultValue="events">
          <TabsList className="mb-6">
            <TabsTrigger value="events">
              {role === "student" ? "My Events" : role === "organizer" ? "Managed Events" : "All Events"}
            </TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            {role !== "student" && <TabsTrigger value="tools">Management Tools</TabsTrigger>}
          </TabsList>

          <TabsContent value="events">
            <DashboardEventList role={role} />
          </TabsContent>

          <TabsContent value="analytics">
            <div className="grid gap-6 md:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle>Event Participation</CardTitle>
                  <CardDescription>Monthly event attendance</CardDescription>
                </CardHeader>
                <CardContent>
                  <DashboardChart type="bar" />
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Event Categories</CardTitle>
                  <CardDescription>Distribution by category</CardDescription>
                </CardHeader>
                <CardContent>
                  <DashboardChart type="pie" />
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {role !== "student" && (
            <TabsContent value="tools">
              <div className="grid gap-6 md:grid-cols-2">
                <Card>
                  <CardHeader>
                    <CardTitle>Bulk Operations</CardTitle>
                    <CardDescription>Import or export event data</CardDescription>
                  </CardHeader>
                  <CardContent className="flex flex-col gap-4">
                    <div className="rounded-lg border border-dashed p-6 text-center">
                      <Upload className="mx-auto mb-2 h-8 w-8 text-muted-foreground" />
                      <p className="mb-1 text-sm font-medium">Upload CSV File</p>
                      <p className="text-xs text-muted-foreground">Drag and drop or click to upload</p>
                      <Button variant="outline" size="sm" className="mt-4">
                        Select File
                      </Button>
                    </div>

                    <Button variant="outline" className="w-full">
                      <Download className="mr-2 h-4 w-4" />
                      Export Participant List
                    </Button>
                  </CardContent>
                </Card>

                {role === "admin" && (
                  <Card>
                    <CardHeader>
                      <CardTitle>Admin Controls</CardTitle>
                      <CardDescription>System management tools</CardDescription>
                    </CardHeader>
                    <CardContent className="flex flex-col gap-3">
                      <Button variant="outline" className="justify-start">
                        Manage User Roles
                      </Button>
                      <Button variant="outline" className="justify-start">
                        Event Approval Queue
                      </Button>
                      <Button variant="outline" className="justify-start">
                        System Settings
                      </Button>
                      <Button variant="outline" className="justify-start">
                        Notification Templates
                      </Button>
                    </CardContent>
                  </Card>
                )}
              </div>
            </TabsContent>
          )}
        </Tabs>
      </div>
    </div>
  )
}

interface StatsCardProps {
  title: string
  value: string
  icon: React.ReactNode
  description: string
  color: "blue" | "green" | "purple" | "amber" | "red"
}

function StatsCard({ title, value, icon, description, color }: StatsCardProps) {
  const colorClasses = {
    blue: "from-blue-50 to-blue-100 text-blue-700 dark:from-blue-900/20 dark:to-blue-800/20 dark:text-blue-400",
    green: "from-green-50 to-green-100 text-green-700 dark:from-green-900/20 dark:to-green-800/20 dark:text-green-400",
    purple:
      "from-purple-50 to-purple-100 text-purple-700 dark:from-purple-900/20 dark:to-purple-800/20 dark:text-purple-400",
    amber: "from-amber-50 to-amber-100 text-amber-700 dark:from-amber-900/20 dark:to-amber-800/20 dark:text-amber-400",
    red: "from-red-50 to-red-100 text-red-700 dark:from-red-900/20 dark:to-red-800/20 dark:text-red-400",
  }

  return (
    <motion.div initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
      <div className={`rounded-xl bg-gradient-to-br ${colorClasses[color]} p-4`}>
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium">{title}</p>
          {icon}
        </div>
        <p className="mt-3 text-2xl font-bold">{value}</p>
        <p className="mt-1 text-xs opacity-70">{description}</p>
      </div>
    </motion.div>
  )
}
