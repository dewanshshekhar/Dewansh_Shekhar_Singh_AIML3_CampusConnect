"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { motion } from "framer-motion"
import { Filter, Plus, Search } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { EventCard } from "@/components/event-card"

export default function EventsPage() {
  const [searchQuery, setSearchQuery] = useState("")
  const [selectedCategories, setSelectedCategories] = useState<string[]>([])
  const [sortBy, setSortBy] = useState("date-asc")
  const [filteredEvents, setFilteredEvents] = useState<any[]>([])

  // Mock events data
  const allEvents = [
    {
      id: 1,
      title: "Tech Innovation Summit",
      description: "Join industry leaders to explore cutting-edge technologies and innovations.",
      image: "/placeholder.svg?height=300&width=500",
      date: "2025-04-15T10:00:00",
      location: "Main Auditorium",
      category: "seminars",
      tags: ["technology", "innovation", "networking"],
      organizer: "Computer Science Department",
      isPaid: true,
      price: 299,
    },
    {
      id: 2,
      title: "Annual Sports Tournament",
      description: "Compete in various sports activities and win exciting prizes.",
      image: "/placeholder.svg?height=300&width=500",
      date: "2025-04-20T09:00:00",
      location: "University Sports Complex",
      category: "sports",
      tags: ["sports", "competition", "fitness"],
      organizer: "Sports Committee",
    },
    {
      id: 3,
      title: "Web Development Workshop",
      description: "Learn modern web development techniques with hands-on exercises.",
      image: "/placeholder.svg?height=300&width=500",
      date: "2025-04-25T14:00:00",
      location: "Computer Lab 101",
      category: "workshops",
      tags: ["coding", "web", "development"],
      organizer: "Tech Club",
      isPaid: true,
      price: 149,
    },
    {
      id: 4,
      title: "Cultural Festival",
      description: "Celebrate diversity through music, dance, and art performances.",
      image: "/placeholder.svg?height=300&width=500",
      date: "2025-05-05T18:00:00",
      location: "University Amphitheater",
      category: "cultural",
      tags: ["culture", "arts", "performance"],
      organizer: "Cultural Committee",
    },
    {
      id: 5,
      title: "Career Fair 2025",
      description: "Connect with top employers and explore career opportunities.",
      image: "/placeholder.svg?height=300&width=500",
      date: "2025-05-10T10:00:00",
      location: "University Hall",
      category: "seminars",
      tags: ["career", "networking", "professional"],
      organizer: "Career Services",
    },
    {
      id: 6,
      title: "UI/UX Design Workshop",
      description: "Master the principles of user interface and experience design.",
      image: "/placeholder.svg?height=300&width=500",
      date: "2025-05-15T13:00:00",
      location: "Design Studio",
      category: "workshops",
      tags: ["design", "ui", "ux"],
      organizer: "Design Club",
      isPaid: true,
      price: 199,
    },
    {
      id: 7,
      title: "Entrepreneurship Summit",
      description: "Learn from successful entrepreneurs and startup founders.",
      image: "/placeholder.svg?height=300&width=500",
      date: "2025-05-20T09:00:00",
      location: "Business School Auditorium",
      category: "seminars",
      tags: ["business", "entrepreneurship", "startups"],
      organizer: "Business School",
    },
    {
      id: 8,
      title: "Photography Exhibition",
      description: "Showcase of stunning photographs from talented university photographers.",
      image: "/placeholder.svg?height=300&width=500",
      date: "2025-05-25T11:00:00",
      location: "Art Gallery",
      category: "cultural",
      tags: ["photography", "arts", "exhibition"],
      organizer: "Photography Club",
    },
    {
      id: 9,
      title: "Debate Competition",
      description: "Showcase your public speaking and critical thinking skills.",
      image: "/placeholder.svg?height=300&width=500",
      date: "2025-06-01T14:00:00",
      location: "Lecture Hall 3",
      category: "academic",
      tags: ["debate", "public speaking", "competition"],
      organizer: "Debate Society",
    },
  ]

  // Filter events based on search query and selected categories
  useEffect(() => {
    const filtered = allEvents.filter((event) => {
      const matchesSearch =
        searchQuery === "" ||
        event.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        event.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        event.tags.some((tag) => tag.toLowerCase().includes(searchQuery.toLowerCase())) ||
        event.organizer.toLowerCase().includes(searchQuery.toLowerCase()) ||
        event.location.toLowerCase().includes(searchQuery.toLowerCase()) ||
        event.category.toLowerCase().includes(searchQuery.toLowerCase())

      const matchesCategory = selectedCategories.length === 0 || selectedCategories.includes(event.category)

      return matchesSearch && matchesCategory
    })

    // Sort events
    const sorted = [...filtered].sort((a, b) => {
      const dateA = new Date(a.date).getTime()
      const dateB = new Date(b.date).getTime()

      switch (sortBy) {
        case "date-asc":
          return dateA - dateB
        case "date-desc":
          return dateB - dateA
        case "title-asc":
          return a.title.localeCompare(b.title)
        case "title-desc":
          return b.title.localeCompare(a.title)
        default:
          return 0
      }
    })

    setFilteredEvents(sorted)
  }, [searchQuery, selectedCategories, sortBy])

  const categories = [
    { id: "workshops", label: "Workshops" },
    { id: "seminars", label: "Seminars" },
    { id: "sports", label: "Sports" },
    { id: "cultural", label: "Cultural" },
    { id: "academic", label: "Academic" },
  ]

  const toggleCategory = (category: string) => {
    setSelectedCategories((prev) =>
      prev.includes(category) ? prev.filter((c) => c !== category) : [...prev, category],
    )
  }

  return (
    <div className="container mx-auto p-4 py-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">All Events</h1>
        <p className="text-muted-foreground">Browse and discover events happening around campus</p>
      </div>

      <div className="mb-8 flex flex-col gap-4 sm:flex-row">
        <div className="flex flex-1 gap-2">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search events..."
              className="pl-8"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
            />
          </div>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="shrink-0">
                <Filter className="h-4 w-4" />
                <span className="sr-only">Filter</span>
              </Button>
            </SheetTrigger>
            <SheetContent>
              <SheetHeader>
                <SheetTitle>Filter Events</SheetTitle>
                <SheetDescription>Narrow down events based on your preferences</SheetDescription>
              </SheetHeader>

              <div className="mt-6 space-y-6">
                <div>
                  <h3 className="mb-4 text-sm font-medium">Categories</h3>
                  <div className="space-y-3">
                    {categories.map((category) => (
                      <div key={category.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`category-${category.id}`}
                          checked={selectedCategories.includes(category.id)}
                          onCheckedChange={() => toggleCategory(category.id)}
                        />
                        <Label htmlFor={`category-${category.id}`}>{category.label}</Label>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                <div>
                  <h3 className="mb-4 text-sm font-medium">Sort By</h3>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select sort order" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="date-asc">Date (Earliest first)</SelectItem>
                      <SelectItem value="date-desc">Date (Latest first)</SelectItem>
                      <SelectItem value="title-asc">Title (A-Z)</SelectItem>
                      <SelectItem value="title-desc">Title (Z-A)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex justify-between">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setSelectedCategories([])
                      setSortBy("date-asc")
                    }}
                  >
                    Reset Filters
                  </Button>
                  <Button type="submit">Apply Filters</Button>
                </div>
              </div>
            </SheetContent>
          </Sheet>
        </div>

        <Select value={sortBy} onValueChange={setSortBy} className="w-full sm:w-[180px]">
          <SelectTrigger>
            <SelectValue placeholder="Sort by" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="date-asc">Date (Earliest first)</SelectItem>
            <SelectItem value="date-desc">Date (Latest first)</SelectItem>
            <SelectItem value="title-asc">Title (A-Z)</SelectItem>
            <SelectItem value="title-desc">Title (Z-A)</SelectItem>
          </SelectContent>
        </Select>

        <Button asChild>
          <Link href="/events/create">
            <Plus className="mr-2 h-4 w-4" />
            Create Event
          </Link>
        </Button>
      </div>

      {selectedCategories.length > 0 && (
        <div className="mb-4 flex flex-wrap gap-2">
          {selectedCategories.map((category) => {
            const categoryLabel = categories.find((c) => c.id === category)?.label
            return (
              <Button
                key={category}
                variant="secondary"
                size="sm"
                className="gap-1"
                onClick={() => toggleCategory(category)}
              >
                {categoryLabel}
                <span className="ml-1 text-xs">×</span>
              </Button>
            )
          })}

          <Button variant="ghost" size="sm" onClick={() => setSelectedCategories([])}>
            Clear all
          </Button>
        </div>
      )}

      {filteredEvents.length === 0 ? (
        <div className="flex min-h-[400px] flex-col items-center justify-center rounded-lg border border-dashed p-8 text-center">
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-muted">
            <Search className="h-10 w-10 text-muted-foreground" />
          </div>
          <h3 className="mt-4 text-lg font-semibold">No events found</h3>
          <p className="mt-2 text-sm text-muted-foreground">Try adjusting your search or filter criteria</p>
          <Button
            className="mt-4"
            onClick={() => {
              setSearchQuery("")
              setSelectedCategories([])
            }}
          >
            Reset filters
          </Button>
        </div>
      ) : (
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredEvents.map((event, index) => (
            <motion.div
              key={event.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
            >
              <EventCard event={event} />
            </motion.div>
          ))}
        </div>
      )}
    </div>
  )
}
