"use client"

import { useState } from "react"
import Link from "next/link"
import { format } from "date-fns"
import { motion } from "framer-motion"
import { ArrowLeft, Calendar, Heart, MapPin, MessageSquare, Share2, User, Users } from "lucide-react"

import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { toast } from "@/components/ui/use-toast"
import { EventComments } from "@/components/event-comments"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

// Define color schemes for different event categories
const categoryColors = {
  workshops: {
    bg: "from-emerald-50 to-emerald-100 dark:from-emerald-900/20 dark:to-emerald-800/20",
    border: "border-emerald-200 dark:border-emerald-800",
    badge: "bg-emerald-500",
    text: "text-emerald-700 dark:text-emerald-300",
  },
  seminars: {
    bg: "from-blue-50 to-blue-100 dark:from-blue-900/20 dark:to-blue-800/20",
    border: "border-blue-200 dark:border-blue-800",
    badge: "bg-blue-500",
    text: "text-blue-700 dark:text-blue-300",
  },
  sports: {
    bg: "from-orange-50 to-orange-100 dark:from-orange-900/20 dark:to-orange-800/20",
    border: "border-orange-200 dark:border-orange-800",
    badge: "bg-orange-500",
    text: "text-orange-700 dark:text-orange-300",
  },
  cultural: {
    bg: "from-purple-50 to-purple-100 dark:from-purple-900/20 dark:to-purple-800/20",
    border: "border-purple-200 dark:border-purple-800",
    badge: "bg-purple-500",
    text: "text-purple-700 dark:text-purple-300",
  },
  academic: {
    bg: "from-amber-50 to-amber-100 dark:from-amber-900/20 dark:to-amber-800/20",
    border: "border-amber-200 dark:border-amber-800",
    badge: "bg-amber-500",
    text: "text-amber-700 dark:text-amber-300",
  },
  // Default color scheme
  default: {
    bg: "from-gray-50 to-gray-100 dark:from-gray-900/20 dark:to-gray-800/20",
    border: "border-gray-200 dark:border-gray-800",
    badge: "bg-gray-500",
    text: "text-gray-700 dark:text-gray-300",
  },
}

export default function EventPage({ params }: { params: { id: string } }) {
  const [isRegistered, setIsRegistered] = useState(false)
  const [isFavorite, setIsFavorite] = useState(false)
  const [showRegistrationDialog, setShowRegistrationDialog] = useState(false)
  const [registrationForm, setRegistrationForm] = useState({
    name: "",
    email: "",
    phone: "",
    rollNumber: "",
  })

  // Mock event data
  const event = {
    id: Number.parseInt(params.id),
    title: "Tech Innovation Summit",
    description:
      "Join industry leaders to explore cutting-edge technologies and innovations that are shaping our future. Network with professionals and gain insights into emerging trends in AI, blockchain, and more.",
    longDescription: `
      <p>The Tech Innovation Summit brings together industry leaders, innovators, and enthusiasts to explore the latest advancements in technology.</p>
      
      <h3>What to Expect:</h3>
      <ul>
        <li>Keynote speeches from renowned tech leaders</li>
        <li>Panel discussions on emerging technologies</li>
        <li>Hands-on workshops and demonstrations</li>
        <li>Networking opportunities with industry professionals</li>
        <li>Exhibition showcasing innovative products and solutions</li>
      </ul>
      
      <h3>Topics Covered:</h3>
      <ul>
        <li>Artificial Intelligence and Machine Learning</li>
        <li>Blockchain and Cryptocurrency</li>
        <li>Internet of Things (IoT)</li>
        <li>Cybersecurity</li>
        <li>Cloud Computing</li>
        <li>Virtual and Augmented Reality</li>
      </ul>
      
      <p>Don't miss this opportunity to stay ahead of the curve and be part of the technological revolution!</p>
    `,
    image: "/placeholder.svg?height=600&width=1200",
    date: "2025-04-15T10:00:00",
    endDate: "2025-04-15T16:00:00",
    location: "Main Auditorium",
    address: "University Campus, 123 Education St, University City",
    category: "seminars",
    tags: ["technology", "innovation", "networking"],
    organizer: "Computer Science Department",
    leadOrganizer: "Dr. Robert Chen",
    convener: "Prof. Sarah Williams",
    coordinator: "John Smith",
    contactNumber: "+91 9876543210",
    isPaid: true,
    price: 299,
    speakers: [
      {
        name: "Dr. Jane Smith",
        role: "AI Researcher, Tech University",
        avatar: "/placeholder.svg?height=100&width=100",
      },
      { name: "John Doe", role: "CTO, Future Technologies", avatar: "/placeholder.svg?height=100&width=100" },
      {
        name: "Sarah Johnson",
        role: "Blockchain Expert, Crypto Solutions",
        avatar: "/placeholder.svg?height=100&width=100",
      },
    ],
    participants: 45,
    maxParticipants: 100,
  }

  const eventDate = new Date(event.date)
  const eventEndDate = new Date(event.endDate)

  // Get color scheme based on event category
  const colorScheme = categoryColors[event.category as keyof typeof categoryColors] || categoryColors.default

  const handleRegister = () => {
    if (event.isPaid) {
      setShowRegistrationDialog(true)
    } else {
      completeRegistration()
    }
  }

  const completeRegistration = () => {
    setIsRegistered(!isRegistered)
    setShowRegistrationDialog(false)

    toast({
      title: isRegistered ? "Registration canceled" : "Successfully registered",
      description: isRegistered
        ? `You have canceled your registration for ${event.title}.`
        : `You have successfully registered for ${event.title}. A confirmation email has been sent to your inbox.`,
      duration: 3000,
    })

    // If this was a paid event and the user just registered, we'd show a success message
    if (!isRegistered && event.isPaid) {
      toast({
        title: "Payment confirmation",
        description: "Payment instructions have been sent to your email with a QR code for completing the transaction.",
        duration: 5000,
      })
    }
  }

  const toggleFavorite = () => {
    setIsFavorite(!isFavorite)
    toast({
      title: isFavorite ? "Removed from favorites" : "Added to favorites",
      description: isFavorite
        ? `${event.title} has been removed from your favorites.`
        : `${event.title} has been added to your favorites.`,
      duration: 3000,
    })
  }

  const shareEvent = () => {
    // In a real app, this would use the Web Share API
    toast({
      title: "Share event",
      description: `Sharing ${event.title} with your friends.`,
      duration: 3000,
    })
  }

  return (
    <div className={cn("min-h-screen bg-gradient-to-b", colorScheme.bg)}>
      <div className="container mx-auto p-4 py-6">
        <div className="mb-6">
          <Button asChild variant="ghost" size="sm" className="mb-4">
            <Link href="/events">
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back to Events
            </Link>
          </Button>

          <div className="flex flex-col justify-between gap-4 md:flex-row md:items-center">
            <div>
              <h1 className={cn("text-3xl font-bold tracking-tight", colorScheme.text)}>{event.title}</h1>
              <p className="text-muted-foreground">Organized by {event.organizer}</p>
            </div>

            <div className="flex gap-2">
              <Button
                variant="outline"
                size="icon"
                onClick={toggleFavorite}
                className={cn(isFavorite ? "text-red-500 hover:text-red-600" : "")}
              >
                <Heart className={cn("h-4 w-4", isFavorite ? "fill-red-500" : "")} />
                <span className="sr-only">{isFavorite ? "Remove from favorites" : "Add to favorites"}</span>
              </Button>

              <Button variant="outline" size="icon" onClick={shareEvent}>
                <Share2 className="h-4 w-4" />
                <span className="sr-only">Share event</span>
              </Button>

              <Button onClick={handleRegister} variant={isRegistered ? "outline" : "default"}>
                {isRegistered ? "Cancel Registration" : "Register Now"}
              </Button>
            </div>
          </div>
        </div>

        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2">
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.3 }}>
              <div className="mb-6 overflow-hidden rounded-lg">
                <img src={event.image || "/placeholder.svg"} alt={event.title} className="h-auto w-full object-cover" />
              </div>

              <Tabs defaultValue="details">
                <TabsList className="mb-4">
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="schedule">Schedule</TabsTrigger>
                  <TabsTrigger value="speakers">Speakers</TabsTrigger>
                  <TabsTrigger value="discussion">Discussion</TabsTrigger>
                  <TabsTrigger value="organizers">Organizers</TabsTrigger>
                </TabsList>

                <TabsContent value="details" className="space-y-4">
                  <div>
                    <h2 className="mb-2 text-2xl font-bold">About This Event</h2>
                    <div
                      className="prose max-w-none dark:prose-invert"
                      dangerouslySetInnerHTML={{ __html: event.longDescription }}
                    />
                  </div>

                  <div>
                    <h3 className="mb-2 text-xl font-bold">Tags</h3>
                    <div className="flex flex-wrap gap-2">
                      {event.tags.map((tag) => (
                        <Badge key={tag} variant="secondary">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="schedule">
                  <div className="space-y-4">
                    <h2 className="mb-4 text-2xl font-bold">Event Schedule</h2>

                    <div className="space-y-4">
                      <div className="rounded-lg border p-4">
                        <div className="mb-2 flex items-center justify-between">
                          <h3 className="font-semibold">Registration & Welcome</h3>
                          <Badge variant="outline">10:00 AM - 10:30 AM</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">Check-in and collect your event materials</p>
                      </div>

                      <div className="rounded-lg border p-4">
                        <div className="mb-2 flex items-center justify-between">
                          <h3 className="font-semibold">Keynote Speech</h3>
                          <Badge variant="outline">10:30 AM - 11:30 AM</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">"The Future of Technology" by Dr. Jane Smith</p>
                      </div>

                      <div className="rounded-lg border p-4">
                        <div className="mb-2 flex items-center justify-between">
                          <h3 className="font-semibold">Networking Break</h3>
                          <Badge variant="outline">11:30 AM - 12:00 PM</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">Refreshments provided</p>
                      </div>

                      <div className="rounded-lg border p-4">
                        <div className="mb-2 flex items-center justify-between">
                          <h3 className="font-semibold">Panel Discussion</h3>
                          <Badge variant="outline">12:00 PM - 1:30 PM</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">
                          "Emerging Technologies and Their Impact" with industry experts
                        </p>
                      </div>

                      <div className="rounded-lg border p-4">
                        <div className="mb-2 flex items-center justify-between">
                          <h3 className="font-semibold">Lunch Break</h3>
                          <Badge variant="outline">1:30 PM - 2:30 PM</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">Catered lunch provided for all attendees</p>
                      </div>

                      <div className="rounded-lg border p-4">
                        <div className="mb-2 flex items-center justify-between">
                          <h3 className="font-semibold">Workshops</h3>
                          <Badge variant="outline">2:30 PM - 4:00 PM</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">Parallel sessions on AI, Blockchain, and IoT</p>
                      </div>

                      <div className="rounded-lg border p-4">
                        <div className="mb-2 flex items-center justify-between">
                          <h3 className="font-semibold">Closing Remarks</h3>
                          <Badge variant="outline">4:00 PM - 4:30 PM</Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">Summary and future directions</p>
                      </div>
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="speakers">
                  <div className="space-y-4">
                    <h2 className="mb-4 text-2xl font-bold">Speakers</h2>

                    <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3">
                      {event.speakers.map((speaker, index) => (
                        <motion.div
                          key={speaker.name}
                          initial={{ opacity: 0, y: 20 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ duration: 0.3, delay: index * 0.1 }}
                        >
                          <Card>
                            <CardHeader className="pb-2 text-center">
                              <Avatar className="mx-auto h-20 w-20">
                                <AvatarImage src={speaker.avatar} alt={speaker.name} />
                                <AvatarFallback>
                                  {speaker.name
                                    .split(" ")
                                    .map((n) => n[0])
                                    .join("")}
                                </AvatarFallback>
                              </Avatar>
                              <CardTitle className="mt-2">{speaker.name}</CardTitle>
                              <CardDescription>{speaker.role}</CardDescription>
                            </CardHeader>
                            <CardContent className="text-center">
                              <Button variant="outline" size="sm">
                                View Profile
                              </Button>
                            </CardContent>
                          </Card>
                        </motion.div>
                      ))}
                    </div>
                  </div>
                </TabsContent>

                <TabsContent value="discussion">
                  <div className="space-y-4">
                    <h2 className="mb-4 text-2xl font-bold">Discussion</h2>

                    <div className="mb-6 space-y-4">
                      <Textarea placeholder="Share your thoughts or ask a question..." className="min-h-[100px]" />
                      <Button>
                        <MessageSquare className="mr-2 h-4 w-4" />
                        Post Comment
                      </Button>
                    </div>

                    <EventComments />
                  </div>
                </TabsContent>

                <TabsContent value="organizers">
                  <div className="space-y-4">
                    <h2 className="mb-4 text-2xl font-bold">Organizers</h2>

                    <div className="space-y-6">
                      <div className="rounded-lg border p-4">
                        <h3 className="mb-2 text-lg font-semibold">Lead Organizer</h3>
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback>RC</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{event.leadOrganizer}</p>
                            <p className="text-sm text-muted-foreground">{event.organizer}</p>
                          </div>
                        </div>
                      </div>

                      <div className="rounded-lg border p-4">
                        <h3 className="mb-2 text-lg font-semibold">Convener</h3>
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback>SW</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{event.convener}</p>
                            <p className="text-sm text-muted-foreground">{event.organizer}</p>
                          </div>
                        </div>
                      </div>

                      <div className="rounded-lg border p-4">
                        <h3 className="mb-2 text-lg font-semibold">Coordinator</h3>
                        <div className="flex items-center gap-3">
                          <Avatar>
                            <AvatarFallback>JS</AvatarFallback>
                          </Avatar>
                          <div>
                            <p className="font-medium">{event.coordinator}</p>
                            <p className="text-sm text-muted-foreground">{event.organizer}</p>
                          </div>
                        </div>
                      </div>

                      <div className="rounded-lg border p-4">
                        <h3 className="mb-2 text-lg font-semibold">Contact Information</h3>
                        <p className="flex items-center gap-2">
                          <span className="font-medium">Phone:</span> {event.contactNumber}
                        </p>
                        <p className="flex items-center gap-2">
                          <span className="font-medium">Email:</span> contact@techinnovationsummit.edu
                        </p>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </motion.div>
          </div>

          <div>
            <div className="space-y-6">
              <Card className={cn("border", colorScheme.border)}>
                <CardHeader>
                  <CardTitle>Event Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-start gap-2">
                    <Calendar className="mt-0.5 h-5 w-5 text-muted-foreground" />
                    <div>
                      <h3 className="font-medium">Date and Time</h3>
                      <p className="text-sm text-muted-foreground">{format(eventDate, "EEEE, MMMM d, yyyy")}</p>
                      <p className="text-sm text-muted-foreground">
                        {format(eventDate, "h:mm a")} - {format(eventEndDate, "h:mm a")}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2">
                    <MapPin className="mt-0.5 h-5 w-5 text-muted-foreground" />
                    <div>
                      <h3 className="font-medium">Location</h3>
                      <p className="text-sm text-muted-foreground">{event.location}</p>
                      <p className="text-sm text-muted-foreground">{event.address}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2">
                    <Users className="mt-0.5 h-5 w-5 text-muted-foreground" />
                    <div>
                      <h3 className="font-medium">Participants</h3>
                      <p className="text-sm text-muted-foreground">
                        {event.participants} registered out of {event.maxParticipants} spots
                      </p>
                      <div className="mt-2">
                        <div className="h-2 w-full overflow-hidden rounded-full bg-secondary">
                          <div
                            className="h-full bg-primary"
                            style={{ width: `${(event.participants / event.maxParticipants) * 100}%` }}
                          ></div>
                        </div>
                      </div>
                    </div>
                  </div>

                  {event.isPaid && (
                    <div className="flex items-start gap-2">
                      <div className="mt-0.5 h-5 w-5 flex-shrink-0 rounded-full bg-green-100 text-center text-green-600 dark:bg-green-900/30">
                        ₹
                      </div>
                      <div>
                        <h3 className="font-medium">Registration Fee</h3>
                        <p className="text-sm text-muted-foreground">₹{event.price}</p>
                        <p className="text-xs text-muted-foreground">Payment instructions will be sent via email</p>
                      </div>
                    </div>
                  )}

                  <div className="flex items-start gap-2">
                    <User className="mt-0.5 h-5 w-5 text-muted-foreground" />
                    <div>
                      <h3 className="font-medium">Organizer</h3>
                      <p className="text-sm text-muted-foreground">{event.organizer}</p>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Similar Events</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Link href="/events/2" className="flex gap-3 rounded-lg p-2 transition-colors hover:bg-muted">
                    <img
                      src="/placeholder.svg?height=60&width=60"
                      alt="Event thumbnail"
                      className="h-15 w-15 rounded-md object-cover"
                    />
                    <div>
                      <h3 className="font-medium">Web Development Workshop</h3>
                      <p className="text-xs text-muted-foreground">April 25, 2025</p>
                    </div>
                  </Link>

                  <Link href="/events/5" className="flex gap-3 rounded-lg p-2 transition-colors hover:bg-muted">
                    <img
                      src="/placeholder.svg?height=60&width=60"
                      alt="Event thumbnail"
                      className="h-15 w-15 rounded-md object-cover"
                    />
                    <div>
                      <h3 className="font-medium">Career Fair 2025</h3>
                      <p className="text-xs text-muted-foreground">May 10, 2025</p>
                    </div>
                  </Link>

                  <Link href="/events/3" className="flex gap-3 rounded-lg p-2 transition-colors hover:bg-muted">
                    <img
                      src="/placeholder.svg?height=60&width=60"
                      alt="Event thumbnail"
                      className="h-15 w-15 rounded-md object-cover"
                    />
                    <div>
                      <h3 className="font-medium">Annual Sports Tournament</h3>
                      <p className="text-xs text-muted-foreground">April 20, 2025</p>
                    </div>
                  </Link>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </div>

      {/* Registration Dialog */}
      <Dialog open={showRegistrationDialog} onOpenChange={setShowRegistrationDialog}>
        <DialogContent className="sm:max-w-[425px]">
          <DialogHeader>
            <DialogTitle>Register for {event.title}</DialogTitle>
            <DialogDescription>
              Fill in your details to complete the registration. Payment instructions will be sent to your email.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="name" className="text-right">
                Name
              </Label>
              <Input
                id="name"
                value={registrationForm.name}
                onChange={(e) => setRegistrationForm({ ...registrationForm, name: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="email" className="text-right">
                Email
              </Label>
              <Input
                id="email"
                type="email"
                value={registrationForm.email}
                onChange={(e) => setRegistrationForm({ ...registrationForm, email: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="phone" className="text-right">
                Phone
              </Label>
              <Input
                id="phone"
                value={registrationForm.phone}
                onChange={(e) => setRegistrationForm({ ...registrationForm, phone: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="grid grid-cols-4 items-center gap-4">
              <Label htmlFor="rollNumber" className="text-right">
                Roll Number
              </Label>
              <Input
                id="rollNumber"
                value={registrationForm.rollNumber}
                onChange={(e) => setRegistrationForm({ ...registrationForm, rollNumber: e.target.value })}
                className="col-span-3"
              />
            </div>
            <div className="col-span-4">
              <p className="text-sm text-muted-foreground">
                Registration fee: <strong>₹{event.price}</strong>
              </p>
              <p className="text-sm text-muted-foreground">
                Payment instructions and QR code will be sent to your email after registration.
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowRegistrationDialog(false)}>
              Cancel
            </Button>
            <Button onClick={completeRegistration}>Complete Registration</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
