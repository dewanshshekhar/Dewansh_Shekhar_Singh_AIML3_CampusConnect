import { createClient } from "@supabase/supabase-js"

// Initialize Supabase client
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || ""
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || ""

export const supabase = createClient(supabaseUrl, supabaseAnonKey)

// Types for our database tables
export type EventType = {
  id: number
  title: string
  description: string
  long_description?: string
  image: string
  date: string
  end_date?: string
  location: string
  address?: string
  category: string
  other_category_details?: string
  tags: string[]
  organizer: string
  lead_organizer: string
  convener: string
  coordinator: string
  contact_number: string
  registration_link?: string
  is_paid: boolean
  price?: number
  max_participants: number
  current_participants: number
  created_at: string
  user_id: string
  needs_volunteers: boolean
  volunteer_roles?: string[]
}

export type UserType = {
  id: string
  email: string
  name: string
  role: "student" | "faculty" | "guest"
  department?: string
  year?: string
  roll_number?: string
  position?: string
  phone?: string
  address?: string
  bio?: string
  avatar_url?: string
}

export type RegistrationType = {
  id: number
  event_id: number
  user_id: string
  registration_date: string
  payment_status?: "pending" | "completed"
  payment_id?: string
  is_volunteer: boolean
  volunteer_role?: string
}

// Helper functions for database operations
export async function fetchEvents(options?: {
  category?: string
  limit?: number
  orderBy?: string
  upcoming?: boolean
}) {
  let query = supabase.from("events").select("*")

  if (options?.category) {
    query = query.eq("category", options.category)
  }

  if (options?.upcoming) {
    query = query.gte("date", new Date().toISOString())
  }

  if (options?.orderBy) {
    query = query.order(options.orderBy)
  }

  if (options?.limit) {
    query = query.limit(options.limit)
  }

  const { data, error } = await query

  if (error) {
    console.error("Error fetching events:", error)
    return []
  }

  return data
}

export async function fetchEventById(id: number) {
  const { data, error } = await supabase.from("events").select("*").eq("id", id).single()

  if (error) {
    console.error("Error fetching event:", error)
    return null
  }

  return data
}

export async function createEvent(event: Omit<EventType, "id" | "created_at" | "current_participants">) {
  const { data, error } = await supabase
    .from("events")
    .insert([
      {
        ...event,
        current_participants: 0,
        created_at: new Date().toISOString(),
      },
    ])
    .select()

  if (error) {
    console.error("Error creating event:", error)
    return null
  }

  return data[0]
}

export async function registerForEvent(eventId: number, userId: string, isVolunteer = false, volunteerRole?: string) {
  // First, check if the user is already registered
  const { data: existingReg } = await supabase
    .from("registrations")
    .select("*")
    .eq("event_id", eventId)
    .eq("user_id", userId)
    .single()

  if (existingReg) {
    console.error("User already registered for this event")
    return { error: "Already registered" }
  }

  // Create registration
  const { data, error } = await supabase
    .from("registrations")
    .insert([
      {
        event_id: eventId,
        user_id: userId,
        registration_date: new Date().toISOString(),
        is_volunteer: isVolunteer,
        volunteer_role: volunteerRole,
      },
    ])
    .select()

  if (error) {
    console.error("Error registering for event:", error)
    return { error: error.message }
  }

  // Update participant count
  await supabase.rpc("increment_participants", { event_id: eventId })

  return { data: data[0] }
}

export async function getCurrentUser() {
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) return null

  const { data } = await supabase.from("users").select("*").eq("id", user.id).single()

  return data
}
