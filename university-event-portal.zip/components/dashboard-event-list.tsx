"use client"

import { useState } from "react"
import Link from "next/link"
import { format } from "date-fns"
import { Calendar, Clock, Edit, MapPin, MoreHorizontal, Trash, Users } from "lucide-react"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { toast } from "@/components/ui/use-toast"

interface DashboardEventListProps {
  role: "student" | "organizer" | "admin"
}

export function DashboardEventList({ role }: DashboardEventListProps) {
  const [events, setEvents] = useState([
    {
      id: 1,
      title: "Tech Innovation Summit",
      date: "2025-04-15T10:00:00",
      location: "Main Auditorium",
      category: "seminars",
      status: "upcoming",
      participants: 45,
    },
    {
      id: 2,
      title: "Annual Sports Tournament",
      date: "2025-04-20T09:00:00",
      location: "University Sports Complex",
      category: "sports",
      status: "upcoming",
      participants: 120,
    },
    {
      id: 3,
      title: "Web Development Workshop",
      date: "2025-03-25T14:00:00",
      location: "Computer Lab 101",
      category: "workshops",
      status: "completed",
      participants: 30,
    },
    {
      id: 4,
      title: "Cultural Festival",
      date: "2025-03-05T18:00:00",
      location: "University Amphitheater",
      category: "cultural",
      status: "completed",
      participants: 200,
    },
  ])

  const handleDeleteEvent = (id: number) => {
    setEvents(events.filter((event) => event.id !== id))
    toast({
      title: "Event deleted",
      description: "The event has been successfully deleted.",
    })
  }

  return (
    <div className="rounded-md border">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Event</TableHead>
            <TableHead>Date & Time</TableHead>
            <TableHead>Location</TableHead>
            <TableHead>Category</TableHead>
            <TableHead>Status</TableHead>
            {role !== "student" && <TableHead>Participants</TableHead>}
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {events.map((event) => {
            const eventDate = new Date(event.date)

            return (
              <TableRow key={event.id}>
                <TableCell className="font-medium">{event.title}</TableCell>
                <TableCell>
                  <div className="flex flex-col">
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                      {format(eventDate, "MMM d, yyyy")}
                    </span>
                    <span className="flex items-center gap-1 text-muted-foreground">
                      <Clock className="h-3.5 w-3.5" />
                      {format(eventDate, "h:mm a")}
                    </span>
                  </div>
                </TableCell>
                <TableCell>
                  <span className="flex items-center gap-1">
                    <MapPin className="h-3.5 w-3.5 text-muted-foreground" />
                    {event.location}
                  </span>
                </TableCell>
                <TableCell>
                  <Badge variant="outline">{event.category.charAt(0).toUpperCase() + event.category.slice(1)}</Badge>
                </TableCell>
                <TableCell>
                  <Badge variant={event.status === "upcoming" ? "default" : "secondary"}>
                    {event.status.charAt(0).toUpperCase() + event.status.slice(1)}
                  </Badge>
                </TableCell>
                {role !== "student" && (
                  <TableCell>
                    <div className="flex items-center gap-1">
                      <Users className="h-3.5 w-3.5 text-muted-foreground" />
                      {event.participants}
                    </div>
                  </TableCell>
                )}
                <TableCell className="text-right">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8">
                        <MoreHorizontal className="h-4 w-4" />
                        <span className="sr-only">Open menu</span>
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem asChild>
                        <Link href={`/events/${event.id}`}>View Details</Link>
                      </DropdownMenuItem>
                      {role !== "student" && (
                        <>
                          <DropdownMenuItem asChild>
                            <Link href={`/events/${event.id}/edit`}>
                              <Edit className="mr-2 h-4 w-4" /> Edit Event
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem
                            className="text-destructive focus:text-destructive"
                            onClick={() => handleDeleteEvent(event.id)}
                          >
                            <Trash className="mr-2 h-4 w-4" /> Delete Event
                          </DropdownMenuItem>
                        </>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </TableCell>
              </TableRow>
            )
          })}
        </TableBody>
      </Table>
    </div>
  )
}
