"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import {
  Calendar,
  Home,
  LogOut,
  Plus,
  Settings,
  User,
  Users,
  BookOpen,
  BarChart,
  Heart,
  HelpCircle,
} from "lucide-react"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"
import { toast } from "@/components/ui/use-toast"
import { useAuth } from "@/contexts/auth-context"

interface SidebarProps {
  trigger: React.ReactNode
}

export function Sidebar({ trigger }: SidebarProps) {
  const router = useRouter()
  const [open, setOpen] = useState(false)
  const { user, signOut } = useAuth()

  const handleLogout = async () => {
    await signOut()
    toast({
      title: "Logged out",
      description: "You have been successfully logged out.",
    })
    setOpen(false)
  }

  const navigateTo = (path: string) => {
    router.push(path)
    setOpen(false)
  }

  const menuItems = [
    { icon: Home, label: "Home", path: "/" },
    { icon: Calendar, label: "Events", path: "/events" },
    { icon: User, label: "Dashboard", path: "/dashboard" },
    { icon: Plus, label: "Create Event", path: "/events/create" },
    { icon: Heart, label: "My Favorites", path: "/favorites" },
    { icon: BookOpen, label: "My Registrations", path: "/registrations" },
  ]

  // Additional menu items based on role
  const roleSpecificItems = {
    student: [{ icon: BarChart, label: "Academic Calendar", path: "/academic-calendar" }],
    faculty: [
      { icon: Users, label: "Manage Events", path: "/manage-events" },
      { icon: BarChart, label: "Analytics", path: "/analytics" },
    ],
    guest: [],
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>{trigger}</SheetTrigger>
      <SheetContent side="left" className="w-[300px] p-0">
        <div className="flex h-full flex-col">
          <SheetHeader className="border-b p-4">
            <SheetTitle className="text-left">CampusConnect</SheetTitle>
          </SheetHeader>

          {user ? (
            <div className="border-b p-4">
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage src={user.avatar_url || ""} alt={user.name} />
                  <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div className="flex-1 overflow-hidden">
                  <h3 className="truncate text-sm font-medium">{user.name}</h3>
                  <p className="truncate text-xs text-muted-foreground">{user.email}</p>
                </div>
                <Badge variant="outline">{user.role}</Badge>
              </div>

              {user.role === "student" && (
                <div className="mt-3 text-xs text-muted-foreground">
                  <p>Roll Number: {user.roll_number}</p>
                  <p>Department: {user.department}</p>
                  <p>Year: {user.year}</p>
                </div>
              )}

              {user.role === "faculty" && (
                <div className="mt-3 text-xs text-muted-foreground">
                  <p>Department: {user.department}</p>
                  <p>Position: {user.position}</p>
                </div>
              )}

              <Button variant="outline" size="sm" className="mt-3 w-full" onClick={() => navigateTo("/profile")}>
                View Profile
              </Button>
            </div>
          ) : (
            <div className="border-b p-4">
              <p className="mb-3 text-sm text-muted-foreground">Sign in to access all features</p>
              <div className="grid gap-2">
                <Button className="w-full" size="sm" onClick={() => navigateTo("/auth/login")}>
                  Sign In
                </Button>
                <Button variant="outline" className="w-full" size="sm" onClick={() => navigateTo("/auth/register")}>
                  Sign Up
                </Button>
              </div>
            </div>
          )}

          <div className="flex-1 overflow-auto py-2">
            <nav className="grid gap-1 px-2">
              {menuItems.map((item) => (
                <Button
                  key={item.label}
                  variant="ghost"
                  className="justify-start"
                  onClick={() => navigateTo(item.path)}
                >
                  <item.icon className="mr-2 h-4 w-4" />
                  {item.label}
                </Button>
              ))}

              {user && user.role && roleSpecificItems[user.role as keyof typeof roleSpecificItems].length > 0 && (
                <>
                  <Separator className="my-2" />
                  {roleSpecificItems[user.role as keyof typeof roleSpecificItems].map((item) => (
                    <Button
                      key={item.label}
                      variant="ghost"
                      className="justify-start"
                      onClick={() => navigateTo(item.path)}
                    >
                      <item.icon className="mr-2 h-4 w-4" />
                      {item.label}
                    </Button>
                  ))}
                </>
              )}
            </nav>
          </div>

          <div className="border-t p-4">
            <div className="grid gap-2">
              <Button variant="ghost" className="justify-start" onClick={() => navigateTo("/settings")}>
                <Settings className="mr-2 h-4 w-4" />
                Settings
              </Button>
              <Button variant="ghost" className="justify-start" onClick={() => navigateTo("/help")}>
                <HelpCircle className="mr-2 h-4 w-4" />
                Help & Support
              </Button>
              {user && (
                <Button
                  variant="ghost"
                  className="justify-start text-red-500 hover:bg-red-50 hover:text-red-600 dark:hover:bg-red-950/50"
                  onClick={handleLogout}
                >
                  <LogOut className="mr-2 h-4 w-4" />
                  Sign Out
                </Button>
              )}
            </div>
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}
