"use client"

import { motion } from "framer-motion"
import { BadgeCheck, Mail, User } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface UserProfileProps {
  role: "student" | "organizer" | "admin"
}

export function UserProfile({ role }: UserProfileProps) {
  // Mock user data based on role
  const userData = {
    student: {
      name: "Alex Johnson",
      email: "alex.johnson@university.edu",
      role: "Student",
      department: "Computer Science",
      year: "3rd Year",
      eventsAttended: 8,
      totalEvents: 12,
      badges: ["Tech Enthusiast", "Sports Fan", "Workshop Pro"],
      points: 320,
      level: 3,
    },
    organizer: {
      name: "Sam Taylor",
      email: "sam.taylor@university.edu",
      role: "Event Organizer",
      department: "Student Activities",
      eventsOrganized: 15,
      upcomingEvents: 2,
      specialization: "Technical Workshops",
    },
    admin: {
      name: "Jordan Smith",
      email: "jordan.smith@university.edu",
      role: "Admin",
      department: "University Administration",
      totalEventsManaged: 120,
      activeEvents: 32,
    },
  }

  const user = userData[role]

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>Profile</CardTitle>
        <CardDescription>Your personal information</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center">
          <div className="mb-4 h-24 w-24 overflow-hidden rounded-full bg-primary/10">
            <User className="h-full w-full p-4 text-primary" />
          </div>

          <h3 className="text-xl font-bold">{user.name}</h3>
          <div className="mb-2 flex items-center gap-1 text-sm text-muted-foreground">
            <Mail className="h-3.5 w-3.5" />
            {user.email}
          </div>

          <Badge className="mb-4">{user.role}</Badge>

          <div className="mb-4 w-full space-y-2 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Department:</span>
              <span>{user.department}</span>
            </div>

            {role === "student" && (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Year:</span>
                  <span>{user.year}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Events Attended:</span>
                  <span>
                    {user.eventsAttended}/{user.totalEvents}
                  </span>
                </div>
              </>
            )}

            {role === "organizer" && (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Events Organized:</span>
                  <span>{user.eventsOrganized}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Upcoming Events:</span>
                  <span>{user.upcomingEvents}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Specialization:</span>
                  <span>{user.specialization}</span>
                </div>
              </>
            )}

            {role === "admin" && (
              <>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Total Events:</span>
                  <span>{user.totalEventsManaged}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Active Events:</span>
                  <span>{user.activeEvents}</span>
                </div>
              </>
            )}
          </div>

          {role === "student" && (
            <div className="w-full">
              <div className="mb-1 flex items-center justify-between">
                <span className="text-sm font-medium">Level {user.level}</span>
                <span className="text-xs text-muted-foreground">{user.points} points</span>
              </div>
              <Progress value={65} className="h-2" />

              <div className="mt-4">
                <h4 className="mb-2 text-sm font-medium">Badges Earned</h4>
                <div className="flex flex-wrap gap-2">
                  {user.badges.map((badge, index) => (
                    <motion.div
                      key={badge}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.3, delay: index * 0.1 }}
                    >
                      <Badge variant="outline" className="flex items-center gap-1">
                        <BadgeCheck className="h-3 w-3" />
                        {badge}
                      </Badge>
                    </motion.div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
