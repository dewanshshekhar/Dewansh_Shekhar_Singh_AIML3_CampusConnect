"use client"

import { useRef } from "react"
import Link from "next/link"
import { motion, useScroll, useTransform } from "framer-motion"
import { ArrowRight, Calendar } from "lucide-react"

import { Button } from "@/components/ui/button"
import { CountdownTimer } from "@/components/countdown-timer"
import type { EventType } from "@/lib/supabase"

interface HeroSectionProps {
  featuredEvent?: EventType | null
}

export function HeroSection({ featuredEvent }: HeroSectionProps) {
  const ref = useRef<HTMLDivElement>(null)
  const { scrollY } = useScroll()
  const y = useTransform(scrollY, [0, 500], [0, 150])
  const opacity = useTransform(scrollY, [0, 300], [1, 0])

  // Calculate event date for countdown
  const eventDate = featuredEvent ? new Date(featuredEvent.date) : new Date(Date.now() + 86400000) // Tomorrow if no event

  return (
    <div ref={ref} className="relative h-[70vh] min-h-[600px] overflow-hidden">
      {/* Background with parallax effect - Updated with more vibrant gradient */}
      <motion.div
        className="absolute inset-0 bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-500"
        style={{ y }}
      />

      {/* Decorative elements - Updated pattern overlay */}
      <div className="absolute inset-0 bg-[url('/placeholder.svg?height=1080&width=1920')] bg-cover bg-center opacity-20 mix-blend-overlay" />

      {/* Add animated particles effect */}
      <div className="absolute inset-0 overflow-hidden">
        {Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={i}
            className="absolute h-2 w-2 rounded-full bg-white opacity-30"
            style={{
              top: `${Math.random() * 100}%`,
              left: `${Math.random() * 100}%`,
            }}
            animate={{
              y: [0, Math.random() * -100],
              opacity: [0.3, 0],
            }}
            transition={{
              duration: 2 + Math.random() * 3,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "loop",
              ease: "linear",
              delay: Math.random() * 2,
            }}
          />
        ))}
      </div>

      <div className="absolute inset-0 bg-gradient-to-t from-background/80 to-transparent" />

      {/* Content */}
      <motion.div
        className="container relative z-10 mx-auto flex h-full flex-col items-center justify-center px-4 text-center"
        style={{ opacity }}
      >
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }}>
          <h1 className="mb-4 text-4xl font-bold tracking-tight text-white sm:text-5xl md:text-6xl">CampusConnect</h1>
          <p className="mx-auto mb-8 max-w-2xl text-lg text-white/90 sm:text-xl">
            Discover, join, and organize exciting events happening around campus
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
          className="mb-8 flex flex-wrap justify-center gap-4"
        >
          <Button asChild size="lg" className="h-12 px-6">
            <Link href="/events">
              Browse Events
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button asChild variant="outline" size="lg" className="h-12 bg-white/10 px-6 backdrop-blur-sm">
            <Link href="/auth/login">Sign In</Link>
          </Button>
        </motion.div>

        {/* Featured event card - Updated with glassmorphism effect */}
        {featuredEvent && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
            className="w-full max-w-2xl overflow-hidden rounded-xl border border-white/20 bg-white/10 p-6 shadow-xl backdrop-blur-md"
          >
            <div className="mb-2 flex items-center justify-between">
              <h3 className="text-xl font-semibold text-white">Featured Event</h3>
              <div className="rounded-full bg-primary/20 px-3 py-1 text-xs font-medium text-primary-foreground backdrop-blur-sm">
                Coming Soon
              </div>
            </div>

            <h2 className="mb-2 text-2xl font-bold text-white">{featuredEvent.title}</h2>
            <p className="mb-4 text-white/80">{featuredEvent.description}</p>

            <div className="mb-4 flex items-center text-white/90">
              <Calendar className="mr-2 h-5 w-5" />
              <span>
                {eventDate.toLocaleDateString("en-US", {
                  weekday: "long",
                  year: "numeric",
                  month: "long",
                  day: "numeric",
                  hour: "2-digit",
                  minute: "2-digit",
                })}
              </span>
            </div>

            <div className="mb-4">
              <CountdownTimer targetDate={eventDate} />
            </div>

            <Button asChild className="w-full">
              <Link href={`/events/${featuredEvent.id}`}>
                Register Now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </motion.div>
        )}
      </motion.div>
    </div>
  )
}
